Development source. Run npm ci, npm run build, npm test. No build is required to use the HTMLs at the root of the ZIP.
