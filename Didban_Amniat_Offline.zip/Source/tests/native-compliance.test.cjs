/* Exercise the actual native functions after the build-time Good Point integration. */
const fs=require('fs'),vm=require('vm'),assert=require('assert/strict'),{spawnSync}=require('child_process');
(async()=>{
 const python=String.raw`from pathlib import Path
import sys,json
sys.argv=['build.py']
text=Path('build.py').read_text().split('# Transform legacy React')[0]
a=text.index('modules=');b=text.index("replace('content=",a)
text=text[:a]+"compiled=''\n"+text[b:]
text=text.replace("['compliance-integration-v12','improvements-integration-v12']","['compliance-integration-v12']")
ns={'__file__':str(Path('build.py').resolve())};exec(text,ns)
print(json.dumps(ns['base']))`;
 const built=spawnSync('python3',['-c',python],{encoding:'utf8',maxBuffer:10*1024*1024});assert.equal(built.status,0,built.stderr);const html=JSON.parse(built.stdout),script=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]).find(s=>s.includes('function iL('));
 const {parse}=await import('@babel/parser'),{default:generate}=await import('@babel/generator'),ast=parse(script);
 const functions=new Set(['iL','DSExtractAuditExtra','dcField','DSAuditExtra','DSSummary','DSTemplateValues','DSFindingsXml']),declarations=new Set(['dcNames','DSExtraFields']),parts=[];
 function visit(node){if(!node||typeof node!=='object')return;if(node.type==='FunctionDeclaration'&&functions.has(node.id?.name)){parts.push(generate(node).code);return;}if(node.type==='VariableDeclarator'&&declarations.has(node.id?.name)){parts.push('const '+generate(node).code+';');return;}for(const [key,value]of Object.entries(node)){if(key==='loc'||key==='extra'||key==='comments')continue;if(Array.isArray(value))value.forEach(visit);else if(value&&typeof value==='object')visit(value);}}
 visit(ast);assert.equal(parts.length,functions.size+declarations.size);
 const J=[{id:'4.1',domain:'4',kind:'clause',title:'شناخت سازمان'},{id:'A.5.1',domain:'A.5',kind:'control',title:'خط‌مشی'},{id:'A.5.2',domain:'A.5',kind:'control',title:'مسئولیت'}],c=vm.createContext({J,JSON,Object,Array,Number,String,Error,DH:(type,props,...children)=>({type,props,children}),dsParagraph:(s)=>s,DSFill:(_,v)=>JSON.stringify(v),DSTemplateParts:{conformTable:'',majorTable:'',minorTable:'',recommendTable:''},DSReviewer:()=>'',DSDescription:()=>'',dsNonempty:s=>s||''});
 vm.runInContext(parts.join('\n')+'\nglobalThis.API={iL,DSExtractAuditExtra,dcField,DSAuditExtra,DSSummary,DSTemplateValues,DSFindingsXml};',c);const A=c.API;
 const assessment=(id,value)=>({id,status:0,compliance:value,previousCompliance:'5',applicable:true,reason:'',documents:'',observations:'',owner:'',action:'',due:''});let checks=0;const test=(name,fn)=>{fn();checks++;console.log('✓',name);};
 test('native audit backup import retains Good Point current and previous values',()=>{const original={assessments:{'4.1':assessment('4.1',5),'A.5.1':assessment('A.5.1',0),'A.5.2':assessment('A.5.2',6)}};const first=A.iL(JSON.stringify(original)),again=A.iL(JSON.stringify({assessments:first}));assert.equal(first['4.1'].compliance,5);assert.equal(first['4.1'].previousCompliance,'5');assert.equal(first['A.5.1'].compliance,0);assert.equal(first['A.5.2'].compliance,null);assert.equal(again['4.1'].compliance,5);assert.equal(again['4.1'].previousCompliance,'5');});
 function find(node,predicate){if(!node||typeof node!=='object')return; if(predicate(node))return node;for(const value of Object.values(node)){for(const child of Array.isArray(value)?value:[value]){const found=find(child,predicate);if(found)return found;}}}
 test('native current and previous selectors use purple class for Good Point only',()=>{for(const field of [A.dcField({value:5}),A.DSAuditExtra({value:{previousCompliance:'5'},onChange(){}})]){const select=find(field,n=>n.type==='select');assert.equal(select.props.className,'dc-good-point-select');const options=[];function gather(n){if(!n||typeof n!=='object')return;if(n.type==='option')options.push(n);Object.values(n).forEach(v=>Array.isArray(v)?v.forEach(gather):gather(v));}gather(select);const good=options.find(n=>String(n.props.value)==='5');assert.ok(good);assert.equal(good.props.className,'dc-good-point-option');assert.ok(good.children.join('').includes('Good Point'));}assert.notEqual(find(A.dcField({value:0}),n=>n.type==='select').props.className,'dc-good-point-select');});
 test('native summary keeps six finding counts and Word placeholder notes aligned',()=>{const data={'4.1':assessment('4.1',5),'A.5.1':assessment('A.5.1',0),'A.5.2':assessment('A.5.2',5)},rows=A.DSSummary(data),total=rows.at(-1),values=A.DSTemplateValues(data,{});assert.equal(total.length,8);assert.equal(total[5],1);assert.equal(total[6],2);assert.equal(values.summary_total_0,1);assert.equal(values.summary_total_5,2);assert.ok(values.summary_total_note.includes('نقطه قوت (Good Point): 2'));assert.ok(values.summary_total_note.includes('تعداد کل الزامات'));const findings=A.DSFindingsXml(data,{});assert.ok(findings.includes('4.6. نقطه قوت (Good Point)'));assert.equal((findings.match(/"finding":"نقطه قوت \(Good Point\)"/g)||[]).length,2);});
 console.log(checks+' native compliance checks passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
